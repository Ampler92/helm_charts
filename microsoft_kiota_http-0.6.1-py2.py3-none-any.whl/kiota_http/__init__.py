"""
Kiota http request adapter implementation for httpx library
"""
from ._version import VERSION

__version__ = VERSION
