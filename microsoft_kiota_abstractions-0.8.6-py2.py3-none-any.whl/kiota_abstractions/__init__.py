"""
Core abstractions for kiota generated libraries in Python
"""
from ._version import VERSION

__version__ = VERSION
