"""
Implementation of Kiota Serialization interfaces for JSON
"""
from ._version import VERSION

__version__ = VERSION
